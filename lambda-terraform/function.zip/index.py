def handler(event, context):
    print("Success!!!")
    return


if __name__ == '__main__':
    handler(None, None)